// export product model
module.exports.Product = require("./product.model");

// export user model
module.exports.User = require("./user.model");
