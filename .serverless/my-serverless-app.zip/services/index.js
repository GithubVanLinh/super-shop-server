module.exports.ProductService = require("./product.service");
module.exports.UserService = require("./user.service");
