// export product controller
module.exports.ProductController = require("./product.controller");

// export user controller
module.exports.UserController = require("./user.controller");
